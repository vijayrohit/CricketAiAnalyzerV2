import { z } from 'zod';

export const BattingStatsSchema = z.object({
  headMovement: z.number().describe('Average head movement during batting (cm).'),
  backliftAngle: z.number().describe('Average backlift angle during batting (degrees).'),
  footworkScore: z.number().describe('Footwork score during batting (0-1).'),
});
export type BattingStats = z.infer<typeof BattingStatsSchema>;

export const BowlingStatsSchema = z.object({
  averageSpeed: z.number().describe('Average bowling speed (km/h).'),
  speedConsistency: z.number().describe('Bowling speed consistency (standard deviation in km/h).'),
  lengthAccuracy: z.number().describe('Bowling length accuracy (percentage of deliveries in ideal zone).'),
  lineAccuracy: z.number().describe('Bowling line accuracy (percentage of deliveries in ideal zone).'),
  swingConsistency: z.number().describe('Bowling swing consistency (standard deviation in degrees).'),
});
export type BowlingStats = z.infer<typeof BowlingStatsSchema>;

export const SessionFormSchema = z.object({
    sessionType: z.enum(['batting', 'bowling']),
    videoDataUri: z.string().nullable().refine(val => val !== null, {
        message: "Please record or upload a video for analysis.",
    }),
});

export type SessionFormValues = z.infer<typeof SessionFormSchema>;
