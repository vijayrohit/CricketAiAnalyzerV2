"use client"

import type { PitchMapDataPoint } from "@/lib/types";
import Image from "next/image";
import { cn } from "@/lib/utils";
import {
    Tooltip,
    TooltipContent,
    TooltipTrigger,
} from "@/components/ui/tooltip";

interface PitchMapProps {
    data: PitchMapDataPoint[];
}

const getResultColor = (result: string) => {
    const lowerResult = result.toLowerCase();
    if (lowerResult.includes('wicket')) return 'bg-red-500 ring-red-300';
    if (lowerResult.includes('good')) return 'bg-green-500 ring-green-300';
    if (lowerResult.includes('yorker')) return 'bg-yellow-500 ring-yellow-300';
    if (lowerResult.includes('bouncer') || lowerResult.includes('short')) return 'bg-blue-500 ring-blue-300';
    if (lowerResult.includes('wide') || lowerResult.includes('no ball')) return 'bg-purple-500 ring-purple-300';
    return 'bg-gray-400 ring-gray-200';
}

export function PitchMap({ data }: PitchMapProps) {
    return (
        <div className="relative w-full max-w-sm mx-auto aspect-[1/2] rounded-lg overflow-hidden bg-green-900/50 border border-white/20">
            <Image 
                src="https://placehold.co/400x800.png" 
                layout="fill" 
                objectFit="cover" 
                alt="Cricket Pitch" 
                data-ai-hint="cricket pitch empty"
                className="opacity-10"
            />
            {/* Creases */}
            <div style={{left: '10%', right: '10%', bottom: '7%'}} className="absolute h-px bg-white/50" />
            <div style={{left: '10%', right: '10%', top: '7%'}} className="absolute h-px bg-white/50" />
            
             {/* Stumps */}
            <div style={{left: '50%', bottom: '7%'}} className="absolute -translate-x-1/2 w-10 h-1 bg-white" />
            <div style={{left: '50%', top: '7%'}} className="absolute -translate-x-1/2 w-10 h-1 bg-white" />

            {data.map((point, index) => (
                 <Tooltip key={index}>
                    <TooltipTrigger asChild>
                        <div
                            className={cn(
                                "absolute w-3 h-3 rounded-full transform -translate-x-1/2 -translate-y-1/2 ring-2 transition-all hover:scale-125 cursor-pointer",
                                getResultColor(point.result)
                            )}
                            style={{ 
                                left: `${point.x}%`, 
                                top: `${point.y}%`
                            }}
                        />
                    </TooltipTrigger>
                    <TooltipContent>
                        <p className="font-semibold">Delivery {index + 1}</p>
                        <p className="text-sm">{point.result}</p>
                        {point.speed && <p className="text-sm text-muted-foreground">{point.speed} km/h</p>}
                    </TooltipContent>
                </Tooltip>
            ))}
        </div>
    )
}
