'use server';

/**
 * @fileOverview A feedback generation AI agent for cricket sessions.
 *
 * - generateAiFeedback - A function that handles the feedback generation process.
 * - GenerateAiFeedbackInput - The input type for the generateAiFeedback function.
 * - GenerateAiFeedbackOutput - The return type for the generateAiFeedback function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import { BattingStatsSchema, BowlingStatsSchema } from '@/lib/types';

const GenerateAiFeedbackInputSchema = z.object({
  sessionType: z.enum(['batting', 'bowling']).describe('The type of the session.'),
  videoDataUri: z.string().describe("A video of the cricket session, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."),
});
export type GenerateAiFeedbackInput = z.infer<typeof GenerateAiFeedbackInputSchema>;

const GenerateAiFeedbackOutputSchema = z.object({
  feedback: z.string().describe('Personalized feedback for the cricket session.'),
  battingStats: BattingStatsSchema.optional().describe('Extracted batting statistics.'),
  bowlingStats: BowlingStatsSchema.optional().describe('Extracted bowling statistics.'),
});
export type GenerateAiFeedbackOutput = z.infer<typeof GenerateAiFeedbackOutputSchema>;

export async function generateAiFeedback(input: GenerateAiFeedbackInput): Promise<GenerateAiFeedbackOutput> {
  return generateAiFeedbackFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateAiFeedbackPrompt',
  input: {schema: GenerateAiFeedbackInputSchema},
  output: {schema: GenerateAiFeedbackOutputSchema},
  prompt: `You are an elite, world-class AI cricket coach with a deep understanding of biomechanics and game strategy. Your analysis is sharp, detailed, and highly technical. You will analyze the provided video of a cricket session to provide professional-grade performance analysis.

The AI must analyze the raw video footage to understand the playing area and all spatial relationships.

Session Type: {{{sessionType}}}
Video of the session: {{media url=videoDataUri}}

Your task is to perform a detailed analysis and provide feedback.

1.  **Technical Analysis & Feedback:**
    -   Go beyond surface-level observations. Provide granular feedback on the player's technique.
    -   If **batting**, analyze:
        -   **Stance and Setup:** Balance, weight distribution, bat position.
        -   **Backlift:** Height, path, and timing. Is it fluid? Is it too high or low?
        -   **Footwork:** Movement towards the ball (forward/back), alignment, and balance upon shot execution.
        -   **Head Position:** Stillness through the shot, eyes level.
        -   **Shot Execution:** Bat swing path, connection point, and follow-through.
    -   If **bowling**, analyze:
        -   **Run-up:** Rhythm, acceleration, and alignment to the crease.
        -   **Action:** Biomechanical efficiency (e.g., front-on, side-on, mixed), arm path, wrist position at release.
        -   **Release Point:** Consistency and height.
        -   **Follow-through:** Deceleration, balance, and direction.
    -   For both, provide 2-3 specific, actionable drills the player can perform to correct any identified flaws.

2.  **Quantitative Metrics:**
    -   Extract the key performance metrics as defined in the output schema. Be as precise as possible.

3.  **Final Output:**
    -   Your final response MUST be in the specified JSON format. Ensure all fields are populated accurately based on your detailed analysis.
`,
});

const generateAiFeedbackFlow = ai.defineFlow(
  {
    name: 'generateAiFeedbackFlow',
    inputSchema: GenerateAiFeedbackInputSchema,
    outputSchema: GenerateAiFeedbackOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
