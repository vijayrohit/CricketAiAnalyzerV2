import type { Metadata } from 'next';
import './globals.css';
import { Toaster } from "@/components/ui/toaster";
import { SidebarProvider, Sidebar, SidebarTrigger, SidebarHeader, SidebarContent, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarInset } from '@/components/ui/sidebar';
import Link from 'next/link';
import { Home, PlusCircle, BarChart3, Bot } from 'lucide-react';

export const metadata: Metadata = {
  title: 'CricketVision Mobile',
  description: 'AI-powered cricket analysis',
};

const AppName = () => (
    <div className="flex items-center gap-2 p-2">
        <Bot className="w-8 h-8 text-primary" />
        <h1 className="text-xl font-headline font-bold text-primary-foreground group-data-[collapsible=icon]:hidden">
            CricketVision
        </h1>
    </div>
);

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased bg-background text-foreground">
        <SidebarProvider>
            <Sidebar>
                <SidebarHeader>
                    <AppName />
                    <SidebarTrigger className="group-data-[collapsible=icon]:hidden"/>
                </SidebarHeader>
                <SidebarContent>
                    <SidebarMenu>
                        <SidebarMenuItem>
                            <Link href="/">
                                <SidebarMenuButton tooltip="Dashboard">
                                    <Home />
                                    <span>Dashboard</span>
                                </SidebarMenuButton>
                            </Link>
                        </SidebarMenuItem>
                        <SidebarMenuItem>
                             <Link href="/new-session">
                                <SidebarMenuButton tooltip="New Session">
                                    <PlusCircle />
                                    <span>New Session</span>
                                </SidebarMenuButton>
                            </Link>
                        </SidebarMenuItem>
                        <SidebarMenuItem>
                             <Link href="/session">
                                <SidebarMenuButton tooltip="Sample Session">
                                    <BarChart3 />
                                    <span>Sample Session</span>
                                </SidebarMenuButton>
                            </Link>
                        </SidebarMenuItem>
                    </SidebarMenu>
                </SidebarContent>
            </Sidebar>
            <SidebarInset>
                {children}
                <Toaster />
            </SidebarInset>
        </SidebarProvider>
      </body>
    </html>
  );
}
