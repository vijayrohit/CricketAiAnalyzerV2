"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { SessionFormSchema, type SessionFormValues } from "@/lib/types";
import { generateFeedbackAction } from "./actions";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Video, VideoOff, SwitchCamera } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";

export function NewSessionClient() {
  const [isClient, setIsClient] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { toast } = useToast();
  const cameraVideoRef = useRef<HTMLVideoElement>(null);
  const uploadVideoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordedVideoUrl, setRecordedVideoUrl] = useState<string | null>(null);
  
  const [uploadedVideoUrl, setUploadedVideoUrl] = useState<string | null>(null);

  const [videoDevices, setVideoDevices] = useState<MediaDeviceInfo[]>([]);
  const [currentDeviceId, setCurrentDeviceId] = useState<string | undefined>();
  
  const [activeTab, setActiveTab] = useState("record");

  const form = useForm<SessionFormValues>({
    resolver: zodResolver(SessionFormSchema),
    defaultValues: {
      sessionType: "batting",
      videoDataUri: null,
    },
  });

  const { formState, handleSubmit, control, setValue, resetField } = form;
  const isSubmitting = formState.isSubmitting;

  useEffect(() => {
    setIsClient(true);
  }, []);

  const getCameraPermissionAndDevices = useCallback(async () => {
    if (!navigator.mediaDevices?.getUserMedia || !navigator.mediaDevices.enumerateDevices) {
      console.error('Camera API not supported in this browser.');
      setHasCameraPermission(false);
      toast({
        variant: 'destructive',
        title: 'Unsupported Browser',
        description: 'The camera functionality is not supported in your browser.',
      });
      return;
    }
    try {
      // Check permission without immediately stopping the track
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      stream.getTracks().forEach(track => track.stop());

      const devices = await navigator.mediaDevices.enumerateDevices();
      const videoInputs = devices.filter(d => d.kind === 'videoinput');
      setVideoDevices(videoInputs);

      if (videoInputs.length > 0) {
          const backCamera = videoInputs.find(d => d.label.toLowerCase().includes('back'));
          setCurrentDeviceId(backCamera?.deviceId || videoInputs[0].deviceId);
      } else {
          setHasCameraPermission(false);
          toast({ variant: 'destructive', title: 'No Camera Found', description: 'No camera devices were found on this device.' });
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
      setHasCameraPermission(false);
      toast({
        variant: 'destructive',
        title: 'Camera Access Denied',
        description: 'Please enable camera permissions in your browser settings.',
      });
    }
  }, [toast]);

  useEffect(() => {
    if (isClient) {
      getCameraPermissionAndDevices();
    }
  }, [isClient, getCameraPermissionAndDevices]);
  
  useEffect(() => {
    if (!currentDeviceId || activeTab !== 'record') {
      return;
    }

    let stream: MediaStream;

    const getStream = async () => {
      try {
        if (cameraVideoRef.current?.srcObject) {
            const currentStream = cameraVideoRef.current.srcObject as MediaStream;
            currentStream.getTracks().forEach(track => track.stop());
        }
        const constraints = { video: { deviceId: { exact: currentDeviceId } } };
        stream = await navigator.mediaDevices.getUserMedia(constraints);
        setHasCameraPermission(true);

        if (cameraVideoRef.current) {
          cameraVideoRef.current.srcObject = stream;
        }
      } catch (error) {
        console.error('Error setting up stream:', error);
        setHasCameraPermission(false);
      }
    };

    if (!isRecording) {
        getStream();
    }
    
    return () => {
      if (stream && !isRecording) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [currentDeviceId, activeTab, isRecording]);


  const handleSwitchCamera = () => {
    if (isRecording || videoDevices.length < 2) return;
    const currentIndex = videoDevices.findIndex(d => d.deviceId === currentDeviceId);
    const nextIndex = (currentIndex + 1) % videoDevices.length;
    setCurrentDeviceId(videoDevices[nextIndex].deviceId);
  };

  const handleStartRecording = () => {
    if (cameraVideoRef.current && cameraVideoRef.current.srcObject) {
      setRecordedVideoUrl(null);
      setValue("videoDataUri", null);
      setError(null);
      setIsRecording(true);

      const stream = cameraVideoRef.current.srcObject as MediaStream;
      mediaRecorderRef.current = new MediaRecorder(stream, { mimeType: 'video/webm' });
      const chunks: Blob[] = [];

      mediaRecorderRef.current.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunks.push(event.data);
        }
      };

      mediaRecorderRef.current.onstop = () => {
        const blob = new Blob(chunks, { type: 'video/webm' });
        const videoUrl = URL.createObjectURL(blob);
        setRecordedVideoUrl(videoUrl);

        const reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = () => {
          const dataUri = reader.result as string;
          setValue("videoDataUri", dataUri);
        };
      };

      mediaRecorderRef.current.start();
    }
  };

  const handleStopRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const videoUrl = URL.createObjectURL(file);
      setUploadedVideoUrl(videoUrl);
      setError(null);

      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onloadend = () => {
        const dataUri = reader.result as string;
        setValue("videoDataUri", dataUri);
      };
    }
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    resetFormState();
  };

  const resetFormState = () => {
    setError(null);
    setRecordedVideoUrl(null);
    setUploadedVideoUrl(null);
    resetField("videoDataUri");
    if (isRecording) {
      handleStopRecording();
    }
  }

  const onSubmit = async (data: SessionFormValues) => {
    setError(null);
    
    if (isRecording) {
        setError("Please stop recording before generating feedback.");
        return;
    }
      
    if (!data.videoDataUri) {
        toast({
            variant: "destructive",
            title: "Missing Video",
            description: "Please record or upload a video for analysis.",
        });
        return;
    }

    const result = await generateFeedbackAction(data);
    if (result.error || !result.data || !result.input) {
      setError(result.error ?? "An unknown error occurred.");
    } else {
      let videoUrlToPass = '';
      if (activeTab === 'record' && recordedVideoUrl) {
          videoUrlToPass = recordedVideoUrl;
      } else if (activeTab === 'upload' && uploadedVideoUrl) {
          videoUrlToPass = uploadedVideoUrl;
      }

      const query = new URLSearchParams({
        type: result.input.sessionType,
        feedback: result.data.feedback,
        ...(result.data.battingStats && { battingStats: JSON.stringify(result.data.battingStats) }),
        ...(result.data.bowlingStats && { bowlingStats: JSON.stringify(result.data.bowlingStats) }),
        ...(videoUrlToPass && { videoUrl: videoUrlToPass }),
      }).toString();
      
      window.location.href = `/session?${query}`;
    }
  };

  const videoForAnalysisUrl = activeTab === 'record' ? recordedVideoUrl : uploadedVideoUrl;

  return (
    <div className="space-y-8">
      <form onSubmit={handleSubmit(onSubmit)}>
        <Card>
          <CardHeader>
            <CardTitle>Create New Analysis</CardTitle>
            <CardDescription>Select session type, then record or upload a video.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="sessionType">Session Type</Label>
              <Controller
                name="sessionType"
                control={control}
                render={({ field }) => (
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <SelectTrigger id="sessionType" className="max-w-xs">
                      <SelectValue placeholder="Select session type..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="batting">Batting</SelectItem>
                      <SelectItem value="bowling">Bowling</SelectItem>
                    </SelectContent>
                  </Select>
                )}
              />
            </div>
            
            <Tabs value={activeTab} onValueChange={handleTabChange}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="record">Record Video</TabsTrigger>
                <TabsTrigger value="upload">Upload Video</TabsTrigger>
              </TabsList>
              <TabsContent value="record" className="mt-6 space-y-4">
                <div className="aspect-[9/16] sm:aspect-video bg-muted rounded-lg flex items-center justify-center relative overflow-hidden">
                  <video ref={cameraVideoRef} className="w-full h-full object-cover" autoPlay muted playsInline />
                  {isClient && hasCameraPermission === false && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/50">
                      <VideoOff className="w-16 h-16 text-muted-foreground" />
                      <p className="mt-2 text-muted-foreground">Camera access denied or not available.</p>
                    </div>
                  )}
                  {isClient && videoDevices.length > 1 && !isRecording && (
                    <Button type="button" variant="outline" size="icon" onClick={handleSwitchCamera} className="absolute bottom-4 right-4 z-10 bg-black/50 hover:bg-black/70 border-white/50 text-white" aria-label="Switch camera">
                      <SwitchCamera className="w-5 h-5" />
                    </Button>
                  )}
                </div>

                {isClient && hasCameraPermission === null && (
                  <div className="flex items-center justify-center mt-4"> <Loader2 className="mr-2 h-4 w-4 animate-spin" /> <span>Accessing camera...</span> </div>
                )}
                
                {isClient && hasCameraPermission === true && (
                  <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <Button type="button" onClick={handleStartRecording} disabled={isRecording} size="lg"> <Video className="mr-2" /> Start Recording </Button>
                    <Button type="button" onClick={handleStopRecording} disabled={!isRecording} variant="destructive" size="lg"> <VideoOff className="mr-2" /> Stop Recording </Button>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="upload" className="mt-6 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="video-upload">Video File</Label>
                    <Input id="video-upload" type="file" accept="video/*" onChange={handleFileChange} />
                  </div>
                  {uploadedVideoUrl && (
                      <div className="space-y-4">
                          <div className="aspect-video bg-muted rounded-lg flex items-center justify-center relative overflow-hidden">
                            <video ref={uploadVideoRef} src={uploadedVideoUrl} className="w-full h-full object-contain" controls />
                          </div>
                      </div>
                  )}
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter className="flex-col items-start gap-4">
            {videoForAnalysisUrl && (
              <Card className="animate-in fade-in w-full">
                <CardHeader>
                  <CardTitle>Review Video</CardTitle>
                  <CardDescription>This video will be sent for analysis. Record or upload again if you're not happy with it.</CardDescription>
                </CardHeader>
                <CardContent>
                  <video src={videoForAnalysisUrl} controls className="w-full rounded-md aspect-video" />
                </CardContent>
              </Card>
            )}
            <Button type="submit" disabled={isSubmitting || !form.getValues("videoDataUri")} className="w-full sm:w-auto">
              {isSubmitting ? (
                <> <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Analyzing Session... </>
              ) : "Analyze Session"}
            </Button>
          </CardFooter>
        </Card>
      </form>
      
      {error && <Card className="border-destructive"><CardContent className="p-4 text-destructive">{error}</CardContent></Card>}

    </div>
  );
}
