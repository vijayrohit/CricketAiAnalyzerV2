"use server";

import { generateAiFeedback, type GenerateAiFeedbackOutput, type GenerateAiFeedbackInput } from "@/ai/flows/generate-ai-feedback";
import { SessionFormSchema, type SessionFormValues } from "@/lib/types";

interface ActionResult {
    data: GenerateAiFeedbackOutput | null;
    error: string | null;
    input: GenerateAiFeedbackInput | null;
}

export async function generateFeedbackAction(formData: SessionFormValues): Promise<ActionResult> {
    const validatedFields = SessionFormSchema.safeParse(formData);

    if (!validatedFields.success) {
        return {
            data: null,
            error: "Invalid data provided. Please check your inputs.",
            input: null,
        };
    }

    if (!validatedFields.data.videoDataUri) {
        return {
           data: null,
           error: "Video data is missing. Please record or upload a session.",
           input: null
       };
   }

    try {
        const input: GenerateAiFeedbackInput = {
            sessionType: validatedFields.data.sessionType,
            videoDataUri: validatedFields.data.videoDataUri,
        };
        
        const feedback = await generateAiFeedback(input);
        return { data: feedback, error: null, input };
    } catch (e) {
        console.error(e);
        return {
            data: null,
            error: "Failed to generate AI feedback. Please try again later.",
            input: null
        };
    }
}
