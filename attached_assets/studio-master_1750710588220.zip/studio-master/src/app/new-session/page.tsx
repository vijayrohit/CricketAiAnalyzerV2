import { NewSessionClient } from "./new-session-client";

export default function NewSessionPage() {
  return (
    <div className="p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
            <h1 className="text-3xl font-headline font-bold">New Video Session Analysis</h1>
            <p className="text-muted-foreground mt-2">
                Record or upload a video of your session and get AI-powered feedback.
            </p>
        </div>
        <NewSessionClient />
      </div>
    </div>
  );
}
