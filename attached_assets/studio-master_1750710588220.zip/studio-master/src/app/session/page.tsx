"use client"
import { useSearchParams } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Footprints, Gauge, Move, Ruler, Target, WandSparkles } from 'lucide-react'
import type { BattingStats, BowlingStats } from '@/lib/types'

const getMetrics = (type: string, bowlingStats?: BowlingStats, battingStats?: BattingStats) => {
    if (type === 'bowling' && bowlingStats) {
        return [
            { name: "Avg Speed", value: `${bowlingStats.averageSpeed} km/h`, icon: <Gauge/> },
            { name: "Speed Consistency", value: `${bowlingStats.speedConsistency} km/h`, icon: <Gauge/> },
            { name: "Length Accuracy", value: `${bowlingStats.lengthAccuracy}%`, icon: <Target/> },
            { name: "Line Accuracy", value: `${bowlingStats.lineAccuracy}%`, icon: <Target/> },
            { name: "Swing Consistency", value: `${bowlingStats.swingConsistency}°`, icon: <WandSparkles/> },
        ]
    }
    if (type === 'batting' && battingStats) {
        return [
            { name: "Head Movement", value: `${battingStats.headMovement} cm`, icon: <Move/> },
            { name: "Backlift Angle", value: `${battingStats.backliftAngle}°`, icon: <Ruler/> },
            { name: "Footwork Score", value: `${battingStats.footworkScore}`, icon: <Footprints/> },
        ]
    }
    return [];
}


export default function SessionPage() {
    const searchParams = useSearchParams()
    const type = searchParams.get('type') || 'bowling';
    const feedback = searchParams.get('feedback') || "No feedback available.";
    const videoUrl = searchParams.get('videoUrl');

    let battingStats: BattingStats | undefined;
    let bowlingStats: BowlingStats | undefined;

    try {
        const battingStatsParam = searchParams.get('battingStats');
        if (battingStatsParam) battingStats = JSON.parse(battingStatsParam);

        const bowlingStatsParam = searchParams.get('bowlingStats');
        if (bowlingStatsParam) bowlingStats = JSON.parse(bowlingStatsParam);

    } catch (e) {
        console.error("Failed to parse session data from URL", e);
    }
    
    const metrics = getMetrics(type, bowlingStats, battingStats);
    const title = type.charAt(0).toUpperCase() + type.slice(1);

    return (
        <main className="p-4 md:p-8 space-y-8">
            <h1 className="text-3xl font-headline font-bold">{title} Session Analysis</h1>
            
            <div className="grid gap-8 lg:grid-cols-3">
                <div className="lg:col-span-2 space-y-8">
                    <Card>
                        <CardHeader><CardTitle>Session Video</CardTitle></CardHeader>
                        <CardContent>
                            <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
                                {videoUrl ? (
                                    <video src={videoUrl} controls className="w-full rounded-md aspect-video" />
                                ) : (
                                    <p>No video available.</p>
                                )}
                            </div>
                        </CardContent>
                    </Card>

                    {metrics.length > 0 && (
                       <Card>
                            <CardHeader><CardTitle>Key Metrics</CardTitle></CardHeader>
                            <CardContent className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                {metrics.map(metric => (
                                    <div key={metric.name} className="p-4 bg-muted/50 rounded-lg">
                                        <div className="flex items-center gap-2 text-sm text-muted-foreground">{metric.icon} {metric.name}</div>
                                        <p className="text-2xl font-bold mt-1">{metric.value}</p>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>
                    )}
                </div>
                
                <div className="lg:col-span-1 space-y-8">
                     <Card>
                        <CardHeader><CardTitle>AI Coach Feedback</CardTitle></CardHeader>
                        <CardContent className="text-muted-foreground leading-relaxed whitespace-pre-wrap">
                            {feedback}
                        </CardContent>
                    </Card>
                </div>
            </div>
        </main>
    );
}
