"use client"
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { ArrowRight, Film, Target, Zap } from "lucide-react";
import Link from "next/link";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { Line, LineChart, CartesianGrid, XAxis, YAxis, ResponsiveContainer } from 'recharts';

const performanceData = [
  { date: 'Jan', speed: 120 },
  { date: 'Feb', speed: 125 },
  { date: 'Mar', speed: 128 },
  { date: 'Apr', speed: 130 },
  { date: 'May', speed: 127 },
  { date: 'Jun', speed: 132 },
];

const chartConfig = {
  speed: {
    label: "Avg Speed (km/h)",
    color: "hsl(var(--primary))",
  },
}

const recentSessions = [
    { id: 1, type: "Batting", date: "2024-07-20", icon: <Zap className="w-6 h-6 text-primary" />, metric: "Backlift Angle", value: "35°" },
    { id: 2, type: "Bowling", date: "2024-07-18", icon: <Target className="w-6 h-6 text-primary" />, metric: "Line Accuracy", value: "85%" },
    { id: 3, type: "Bowling", date: "2024-07-15", icon: <Zap className="w-6 h-6 text-primary" />, metric: "Avg. Speed", value: "135 km/h" },
];

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-1 p-4 md:p-8 space-y-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <h1 className="text-3xl font-headline font-bold">Dashboard</h1>
          <Link href="/new-session">
            <Button size="lg">Start New Session</Button>
          </Link>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Performance Overview</CardTitle>
            <CardDescription>Average Bowling Speed Over Time</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer config={chartConfig} className="h-[250px] w-full">
              <ResponsiveContainer>
                <LineChart data={performanceData}>
                  <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="date" tickLine={false} axisLine={false} tickMargin={8} />
                  <YAxis
                    tickLine={false}
                    axisLine={false}
                    tickMargin={8}
                    tickFormatter={(value) => `${value} km/h`}
                  />
                  <ChartTooltip
                    cursor={false}
                    content={<ChartTooltipContent indicator="dot" />}
                  />
                  <Line dataKey="speed" type="monotone" stroke="hsl(var(--primary))" strokeWidth={2} dot={true} />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        <div>
          <h2 className="text-2xl font-headline font-bold mb-4">Recent Sessions</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {recentSessions.map((session) => (
              <Card key={session.id} className="flex flex-col">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {session.icon}
                      <CardTitle className="text-xl">{session.type} Session</CardTitle>
                    </div>
                    <Link href={`/session?type=${session.type.toLowerCase()}`} className="text-primary hover:underline">
                      <ArrowRight className="w-5 h-5" />
                    </Link>
                  </div>
                  <CardDescription>{session.date}</CardDescription>
                </CardHeader>
                <CardContent className="flex-grow">
                  <div className="flex items-baseline gap-2">
                    <p className="text-sm text-muted-foreground">{session.metric}:</p>
                    <p className="text-2xl font-bold">{session.value}</p>
                  </div>
                </CardContent>
                 <CardFooter className="flex justify-between items-center">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Film className="w-4 h-4"/>
                        <span>Video available</span>
                    </div>
                     <Link href={`/session?type=${session.type.toLowerCase()}`}>
                         <Button variant="outline">View Analysis</Button>
                    </Link>
                 </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
