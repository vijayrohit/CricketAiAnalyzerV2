# **App Name**: CricketVision Mobile

## Core Features:

- Session Recording: Allow the user to record cricket sessions using the device camera.
- On-Device AI Analysis: Utilize on-device AI models to analyze cricket sessions, providing metrics for batting and bowling performance; the AI tool will identify key events, player actions, and ball trajectory, on-device.
- Metric Display: Display session metrics, including bowling speed, swing deviation, batting backlift angle, and head movement, clearly on screen.
- Session Dashboard: Provide a dashboard with a timeline, to browse session thumbnails, performance charts, and analysis reports for easy session management.
- AI Feedback Generation: Generate feedback for batting and bowling based on AI analysis. Use a generative AI tool to decide when to suggest particular exercises or recommendations, based on performance during the session.
- Visualization Components: Display key metrics and improvement timelines using line graphs, radar charts and tables. Overlay visualizations on the video playback for immediate, contextual performance evaluation.
- Storage Management: Compress recorded video and extracted data. Allow pruning of old sessions.

## Style Guidelines:

- Primary color: Deep indigo (#4B0082), to convey both intelligence, data analysis, and athletic activity.
- Background color: Dark gray (#333333), to enhance contrast and reduce eye strain during long analysis sessions.
- Accent color: Vibrant violet (#9400D3) for highlighting key metrics and interactive elements, providing a clear visual hierarchy.
- Headline font: 'Space Grotesk', sans-serif, for a techy, modern, data-driven feel.
- Body font: 'Inter', sans-serif, to provide clear, readable information without drawing undue attention.
- Use minimalist icons to represent various metrics (speed, angle, accuracy, etc.).
- Use subtle transitions and animations to smoothly update charts and display analysis data, improving the overall user experience without being distracting.